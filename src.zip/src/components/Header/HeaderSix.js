import React from "react";
import MenuSix from "./Menu/MenuSix";

export default function HeaderSix(props) {
  return <MenuSix {...props} />;
}
